package bankaccountapp;

public class Savings extends Account {

	private int safetyDepositBoxId;
	private int safetyDepositBoxKey;
	// list properties specific to savings account
	// list any method specific to savings account
	// constructor to initialize settings for the savings properties
	public Savings(String name, String SSN, double initDeposit) {
		super(name, SSN, initDeposit);
		accountNumber = "1" + accountNumber;
		setsafetyDepositBox();
	}

	@Override
	public void setRate() {
		// TODO Auto-generated method stub
		// System.out.println("Implement rate for savings");
		rate = getbaserate() - 0.25;

	}
	private void setsafetyDepositBox() {
		safetyDepositBoxId = (int) (Math.random() * Math.pow(10, 3));
		// System.out.println(safetyDepositBoxId);
		safetyDepositBoxKey = (int) (Math.random() * Math.pow(10, 4));
	}



	@Override
	public void showInfo() {
		// System.out.println("ACCOUNT TYPE: Savings");
		super.showInfo();
		System.out.println("Your savings account features: " + "\nSafety deposite box id: " + safetyDepositBoxId
				+ "\nsafetyDeposit Box  Key : " + safetyDepositBoxKey);

	}


}
