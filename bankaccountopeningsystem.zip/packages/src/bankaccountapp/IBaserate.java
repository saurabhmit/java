package bankaccountapp;

public interface IBaserate {

	// Write a method that returns the base rate
	default double getbaserate() {
		return 3;
	}

}
