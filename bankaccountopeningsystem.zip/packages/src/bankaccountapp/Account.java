package bankaccountapp;

public abstract class Account implements IBaserate {
	// list common property for saving and checking account

//constructor to set base properties and initialize the account

	private String name;
	private String SSN;
	private double balance;
	private static int index = 10000;
	protected String accountNumber;
	protected double rate;

	public Account(String name, String SSN, double initDeposit) {
		this.name = name;
		this.SSN = SSN;
		balance = initDeposit;
		// System.out.println("NAME: " + name + " SSN: " + SSN + " BALANCE: $ " +
		// balance);

		// System.out.println("NAME:" + name);
		// System.out.print("NEW ACCOUNT: ");
		index++;
		this.accountNumber = setAccountNumber();
		setRate();
		// System.out.println(getbaserate());
	}

	public abstract void setRate();
	// set account number

	private String setAccountNumber() {
		String lastwoofSSN = SSN.substring(SSN.length() - 2, SSN.length());
		int uniqueID = index;
		int randomNumber = (int) (Math.random() * Math.pow(10, 3));
		return lastwoofSSN + uniqueID + randomNumber;
	}

	public void compound() {
		double accruedInterest = balance * (rate / 100);
		balance = balance + accruedInterest;
		System.out.println("AccruedInterest $ : " + accruedInterest);
		printBalance();
	}

	public void deposit(double amount) {
		balance = balance + amount;
		System.out.println("Depositing $ " + amount);
		printBalance();

	}

	public void withdraw(double amount) {
		balance = balance - amount;
		System.out.println("Withdrawing $ " + amount);
		printBalance();
	}

	public void transfer(String toWhere, double amount) {
		balance = balance - amount;
		System.out.println("Transferring $ " + amount + " to " + toWhere);
		printBalance();
	}

	public void printBalance() {
		System.out.println("Your balance is: " + balance);
	}

	public void showInfo() {
		System.out.println("NAME: " + name + "\n ACCOUNT NUMBER : " + accountNumber + "\n BALANCE:" + balance
				+ "\nRATE: " + rate + "%");
	}

}


